
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
	<!-- <link rel="stylesheet" type="text/css" href="assets/fonts/brands.min.css">
	<link rel="stylesheet" type="text/css" href="assets/fonts/all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/fonts/fontawesome.min.css"> -->
	
</head>